# laravel-jwt-auth
Laravel 7 JWT Authentication example tutorial. Create secure REST API in Laravel using JSON Web Token (JWT). Protect user authentication API with tymondesigns/jwt-auth JWT package.

[Laravel 7 JWT Authentication Tutorial: User Login & Signup API](https://www.positronx.io/laravel-jwt-authentication-tutorial-user-login-signup-api/)