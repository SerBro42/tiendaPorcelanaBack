


<img src="<?php echo e(url('storage/app/public/images/'.'belvedere-41070748_1651599224.jpg')); ?>" alt="" title="" /><?php /**PATH D:\Carpeta de Sergio\FP\2º\Proyecto final\tiendaPorcelanaBack\backend-master\resources\views/helloworld.blade.php ENDPATH**/ ?>